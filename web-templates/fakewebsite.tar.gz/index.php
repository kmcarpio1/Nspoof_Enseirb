<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hacké</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #000;
            color: #fff;
            font-family: Arial, sans-serif;
            text-align: center;
        }
        h1 {
            font-size: 4rem;
            margin: 0;
        }
        .smiley {
            font-size: 6rem;
            margin-top: 1rem;
        }
    </style>
</head>
<body>
    <div>
        <h1>Tu t'es fait hacké !</h1>
        <div class="smiley">😛</div>
    </div>
</body>
</html>

